export function calculateR2(r1, b) {
  return parseFloat((r1 * (b / 100)).toFixed(2));
}

