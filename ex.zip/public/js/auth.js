async function register() {
  const username = v("username"), passwd = v("passwd"), stunum = v("stunum");
  const res = await fetch("/api/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, passwd, stunum }),
  });
  const data = await res.json();
  msg(data.success ? "✅ 회원가입 완료!" : "❌ " + data.error);
}

async function login() {
  const username = v("username"), passwd = v("passwd"), stunum = v("stunum");
  const res = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, passwd, stunum }),
  });
  const data = await res.json();
  if (data.success) {
    localStorage.setItem("username", username);
    localStorage.setItem("passwd", passwd);
    localStorage.setItem("stunum", stunum);
    location.href = "dashboard.html";
  } else msg("❌ " + data.error);
}

function msg(text) {
  document.getElementById("msg").textContent = text;
}
function v(id) {
  return document.getElementById(id).value.trim();
}

