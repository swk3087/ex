const idToken = localStorage.getItem("idToken");
if(!idToken) location.href="index.html";

const subjectOrder = ["korean","math","history","science","english","chinese","morality","pe","tech","art"];

async function loadData(){
  const res = await fetch("/api/user", { headers:{ "Authorization":"Bearer "+idToken } });
  const { userData, defaultData, maxData } = await res.json();
  const container = document.getElementById("scoreArea");
  container.innerHTML="";

  for(const subject of subjectOrder){
    if(!userData[subject]) continue;
    const div = document.createElement("div");
    div.className="subject-card";
    div.innerHTML = `<h3>${translate(subject)}</h3>`;
    let total=0;

    for(const [key, val] of Object.entries(userData[subject])){
      const info = defaultData[subject]?.[key];
      const maxR1 = maxData[subject]?.[key]?.r1 ?? 100;
      const name = info?.name ?? key;
      total += val.r2 ?? 0;

      div.innerHTML += `
        <label>${name}  만점 : ${maxR1}</label>
        <input type="number" min="0" max="${maxR1}" value="${val.r1}"
               onchange="updateScore('${subject}','${key}',this.value)">
        <span>→ ${val.r2}</span><br>
      `;
    }

    div.innerHTML += `<b>총점: ${total.toFixed(2)}</b>`;
    container.appendChild(div);
  }
}
loadData();

async function updateScore(subject,key,value){
  await fetch("/api/update", {
    method:"POST",
    headers:{ "Content-Type":"application/json", "Authorization":"Bearer "+idToken },
    body: JSON.stringify({ subject, key, value:Number(value) })
  });
  loadData();
}

function logout(){
  localStorage.removeItem("idToken");
  firebase.auth().signOut();
  location.href="index.html";
}

function translate(code){
  const map={ korean:"국어", math:"수학", history:"역사", science:"과학", english:"영어", chinese:"중국어", morality:"도덕", pe:"체육", tech:"기술·가정", art:"미술" };
  return map[code] ?? code;
}

