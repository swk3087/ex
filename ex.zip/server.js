import express from "express";
import bodyParser from "body-parser";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import admin from "firebase-admin";
import { readJSON, writeJSON, ensureDir } from "./utils/fileUtil.js";
import { calculateR2 } from "./utils/scoreUtil.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

const dataDir = path.join(__dirname, "data");
const usersDir = path.join(dataDir, "users");
const logDir = path.join(__dirname, "log");
const stunumFile = path.join(dataDir, "stunum.json");
await ensureDir(usersDir);
await ensureDir(logDir);
if (!fs.existsSync(stunumFile)) await writeJSON(stunumFile, {});

// ===== Firebase Admin =====
admin.initializeApp({
  credential: admin.credential.cert(
    JSON.parse(fs.readFileSync(path.join(__dirname, "firebase-admin.json"), "utf8"))
  ),
});

// ===== Logger =====
function writeLog(type, msg) {
  const today = new Date().toISOString().split("T")[0];
  const logPath = path.join(logDir, `${today}.log`);
  const time = new Date().toLocaleString("ko-KR");
  const line = `[${time}] [${type}] ${msg}\n`;
  fs.appendFileSync(logPath, line);
  console.log(line.trim());
}

// ===== Auth middleware =====
async function authRequired(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    const token = h.startsWith("Bearer ") ? h.slice(7) : null;
    if (!token) return res.status(401).json({ error: "No token" });
    const decoded = await admin.auth().verifyIdToken(token);
    req.uid = decoded.uid;
    req.email = decoded.email || "";
    next();
    console.log("Auth Header:", req.headers.authorization);

  } catch (e) {
    writeLog("AUTH", `❌ Invalid token: ${e.message}`);
    res.status(401).json({ error: "Invalid token" });
  }
}

// ===== Register: 학번 저장 & 사용자 파일 초기화 =====
app.post("/api/register", authRequired, async (req, res) => {
  try {
    const { stunum } = req.body;
    if (!/^\d{4}$/.test(String(stunum || "")))
      return res.status(400).json({ error: "학번은 4자리 숫자여야 합니다." });

    const stunumData = await readJSON(stunumFile);
    // 학번 중복 방지 (이미 다른 uid가 쓰고 있으면 거부)
    const usedBy = Object.entries(stunumData).find(([, v]) => v === stunum);
    if (usedBy && usedBy[0] !== req.uid)
      return res.status(400).json({ error: "이미 등록된 학번입니다." });

    // 사용자 파일이 없으면 초기화
    const userPath = path.join(usersDir, `${req.uid}.json`);
    if (!fs.existsSync(userPath)) {
      const maxinput = await readJSON(path.join(dataDir, "maxinput.json"));
      const userData = {};
      for (const [subject, items] of Object.entries(maxinput)) {
        userData[subject] = {};
        for (const [key] of Object.entries(items)) {
          userData[subject][key] = { r1: 0, r2: 0 };
        }
      }
      await writeJSON(userPath, userData);
    }

    // 학번 저장/갱신
    stunumData[req.uid] = stunum;
    await writeJSON(stunumFile, stunumData);

    writeLog("REGISTER", `✅ uid=${req.uid} email=${req.email} stunum=${stunum}`);
    res.json({ success: true });
  } catch (e) {
    writeLog("REGISTER", `❌ ${e.message}`);
    res.status(500).json({ error: "서버 오류" });
  }
});

// ===== 사용자 데이터 조회 =====
app.get("/api/user", authRequired, async (req, res) => {
  try {
    const userPath = path.join(usersDir, `${req.uid}.json`);
    if (!fs.existsSync(userPath)) return res.status(404).json({ error: "사용자 데이터 없음" });

    const userData = await readJSON(userPath);
    const defaultData = await readJSON(path.join(dataDir, "default.json"));
    const maxData = await readJSON(path.join(dataDir, "maxinput.json"));

    writeLog("FETCH", `📖 uid=${req.uid} 데이터 조회`);
    res.json({ userData, defaultData, maxData, email: req.email });
  } catch (e) {
    writeLog("FETCH", `❌ ${e.message}`);
    res.status(500).json({ error: "서버 오류" });
  }
});

// ===== 점수 업데이트 =====
app.post("/api/update", authRequired, async (req, res) => {
  try {
    const { subject, key, value } = req.body;
    const userPath = path.join(usersDir, `${req.uid}.json`);
    if (!fs.existsSync(userPath)) return res.status(404).json({ error: "사용자 데이터 없음" });

    const userData = await readJSON(userPath);
    const defaultData = await readJSON(path.join(dataDir, "default.json"));
    const maxData = await readJSON(path.join(dataDir, "maxinput.json"));

    if (!userData[subject]?.[key]) return res.status(400).json({ error: "유효하지 않은 항목" });

    const maxR1 = maxData[subject]?.[key]?.r1 ?? 0;
    const b = defaultData[subject]?.[key]?.b ?? 0;

    const v = Number(value);
    if (isNaN(v) || v < 0 || v > maxR1)
      return res.status(400).json({ error: `입력값은 0~${maxR1} 사이여야 합니다.` });

    userData[subject][key].r1 = v;
    userData[subject][key].r2 = calculateR2(v, b);
    await writeJSON(userPath, userData);

    writeLog("UPDATE", `✏️ uid=${req.uid} ${subject}.${key} r1=${v}, r2=${userData[subject][key].r2}`);
    res.json({ success: true, updated: userData[subject][key] });
  } catch (e) {
    writeLog("UPDATE", `❌ ${e.message}`);
    res.status(500).json({ error: "서버 오류" });
  }
});

// ===== server start =====
app.listen(PORT, () => writeLog("SYSTEM", `🚀 http://localhost:${PORT}`));

